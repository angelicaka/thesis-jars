abstract class Routes {
  static const String initial = '/screens';
  static const String home = '/home';
  static const String search = '/search';
  static const String cart = '/cart';
}
