import 'package:flutter/cupertino.dart';

class AppColors{
  static const Color deep_orange = Color(0xFFFF6B6B);
}