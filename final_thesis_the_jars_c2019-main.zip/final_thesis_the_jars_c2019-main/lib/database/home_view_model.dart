// import 'package:final_thesis_the_jars_c2019/database/auth_controller.dart';
// import 'package:get/get.dart';
// import 'package:flutter/material.dart';
// class CategoryModel{
//   final String image, name;
//   CategoryModel({
//     required this.image, 
//     required this.name,
//     });
   
// }