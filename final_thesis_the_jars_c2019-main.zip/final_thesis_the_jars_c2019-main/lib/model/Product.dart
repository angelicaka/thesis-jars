// import 'package:flutter/material.dart';

// class product{
//     String? description;
//    String? image;
//    String? name;
//    String? price;
 
//   product({
//      this.name, 
//      this.image,
//      this.description, 
//      this.price
//     });

// //   product.fromMap(DocumentSnapsshot data){
   
// //     description = data["description"];
// //     image = data["image"];
// //     name = data["name"];
// //     price = data["price"];
   
// // }

//     // factory Product.fromJson(Map<String, dynamic> json){
//     //   return Product(
//     //     image: json['image'], 
//     //     name: json['name'], 
//     //     description: json['description'], 
//     //     price: json['price'],);
//     // }
// //}