package com.example.final_thesis_the_jars_c2019

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
